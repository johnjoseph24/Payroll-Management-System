package com.payroll.Model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayRollManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
